import { SweetsTable, DessertsTable } from "./components";
import { Container } from "react-bootstrap";

export const Landing = () => {
  return (
    <Container>
      <h1 className="mt-5 ps-3">Desserts</h1>
      <DessertsTable />
      <h1 className="mt-5 ps-3">Sweets</h1>
      <SweetsTable />
    </Container>
  );
};
