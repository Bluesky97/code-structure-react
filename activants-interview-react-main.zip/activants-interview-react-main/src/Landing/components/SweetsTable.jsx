import React, { useState } from "react";
import { Container, Table } from "react-bootstrap";

export const SweetsTable = () => {
  const [data, setData] = useState([]);

  return (
    <Container>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Id</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Type</th>
          </tr>
        </thead>
        <tbody>
          {data.map((element, index) => (
            <tr key={index}>
              <td>{element.id}</td>
              <td>{element.name}</td>
              <td>{element.quantity}</td>
              <td>{element.type}</td>
            </tr>
          ))}
        </tbody>
      </Table>
    </Container>
  );
};
