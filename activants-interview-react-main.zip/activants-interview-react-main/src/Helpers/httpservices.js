import axios from "axios";

const server = "";
let instance = axios.create();

export const GetData = async (url) => {
  instance.defaults.headers.common["Content-Type"] = "application/json";
  instance.defaults.headers.common["Accept"] = "*/*";

  return new Promise(async (resolve, reject) => {
    await instance
      .get(`${server}/${url}`)
      .then((response) => {
        if (response.status >= 200 && response.status <= 299) {
          resolve(response.data);
        } else {
          reject(Error("No data found"));
        }
      })
      .catch((error) => {
        reject(Error(`An error occurred: ${error}`));
      });
  });
};
